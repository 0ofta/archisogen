#!/bin/bash

set -e -u

sed -i 's/#\(nb_NO.UTF-8\)/\1/' /etc/locale.gen
locale-gen

ln -sf /usr/share/zoneinfo/UTC /etc/localtime

usermod -s /usr/bin/zsh root
cp -aT /etc/skel/ /root/
chmod 700 /root

sed -i 's/#\(PermitRootLogin \).\+/\1yes/' /etc/ssh/sshd_config
sed -i "s/#Server/Server/g" /etc/pacman.d/mirrorlist
sed -i 's/#\(Storage=\)auto/\1volatile/' /etc/systemd/journald.conf

sed -i 's/#\(HandleSuspendKey=\)suspend/\1ignore/' /etc/systemd/logind.conf
sed -i 's/#\(HandleHibernateKey=\)hibernate/\1ignore/' /etc/systemd/logind.conf
sed -i 's/#\(HandleLidSwitch=\)suspend/\1ignore/' /etc/systemd/logind.conf

systemctl enable slim.service
systemctl enable pacman-init.service choose-mirror.service
systemctl set-default graphical.target

groupadd nmm
groupadd sudo
useradd -m -g nmm -G sudo  nmm
usermod -aG lock nmm
usermod -aG uucp nmm
chown -R nmm:nmm /home/nmm

echo "ROOT PASSWORD:"
passwd 
echo "NMM USER PASSWORD:"
passwd nmm

visudo

echo kodeklubben > /etc/hostname

mv /usr/share/slim/themes/default/background.jpg{,.bck}
ln -s /home/nmm/archkodeklubben.jpg /usr/share/slim/themes/default/background.jpg

mv /home/nmm/slim.conf /etc/slim.conf
mv /home/nmm/locale.conf /etc/locale.conf
