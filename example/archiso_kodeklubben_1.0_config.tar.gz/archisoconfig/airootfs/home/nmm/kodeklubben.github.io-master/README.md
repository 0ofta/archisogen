kodeklubben.github.io
=====================

Dette er filene for nettstedet <http://kodeklubben.github.io/> som inneholder [kodeklubbens oppgaver](//github.com/kodeklubben/oppgaver) som html. Dersom du ønsker å gjøre endringer til nettstedet må du gjøre endringen i [utgangspunktet som finnes her](//github.com/kodeklubben/oppgaver/), ettersom filene i dette repoet blir generert automatisk.
